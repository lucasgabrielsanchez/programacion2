﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Data.SqlClient;

namespace Sanchez.Lucas._2C
{
    public partial class Form1 : Form
    {
        private Mascotera<Mascota> mascotera;
        FileStream Archivo;

        public Form1()
        {
            InitializeComponent();
        }


        private void Form1_Load(object sender, EventArgs e)
        {
            this.mascotera = new Mascotera<Mascota>();
            this.btn01.Click += this.CrearMascota;
        }

        private void CrearMascota(object sender, EventArgs e)
        {
            Mascota mascotita = new Mascota("Carlos");
            this.mascotera += mascotita;
            this.btn02.Click += this.CrearPerro;
        }

        private void CrearPerro(object sender, EventArgs e)
        {
            Perro perrito = new Perro("Pedro");
            this.mascotera += perrito;
            this.btn03.Click += this.GuardarArchivo;
        }

        private void GuardarArchivo(object sender, EventArgs e)
        {
            try
            {
                FileStream stream = new FileStream("Serializado.bin", FileMode.Create);

                BinaryFormatter formater = new BinaryFormatter();

                formater.Serialize(stream, this.mascotera.MisMascotas[0]);

                stream.Close();
            }
            catch
            {
                MessageBox.Show("Error");
            }
            this.btn04.Click += this.TraerArchivo;
        }

        private void TraerArchivo(object sender, EventArgs e)
        {
            if (File.Exists("archivo"))
            {
                try
                {
                    FileStream leido = new FileStream("Serializado.bin", FileMode.Open);

                    BinaryFormatter formater = new BinaryFormatter();

                    Mascota mascotaLeida = null;

                    mascotaLeida = (Mascota)formater.Deserialize(leido);

                    this.mascotera.MisMascotas.Add(mascotaLeida);

                    leido.Close();
                }

                catch
                {
                    MessageBox.Show("Error");
                }
                
            }
            this.btn06.Click += this.Mostrar;
        }

        private void Mostrar(object sender, EventArgs e)
        {
            StringBuilder sb = new StringBuilder();

            foreach (Mascota item in this.mascotera.MisMascotas)
            {
                try
                {
                    if (item is Perro)
                    {
                        sb.AppendLine(((Perro)item).EmitirSonido());
                    }
                    else
                    {
                        sb.AppendLine(((Mascota)item).EmitirSonido());
                    }
                    
                }
                
                catch (Exception f)
                {
                    sb.AppendLine(f.Message);
                    continue;
                }   
            }

            MessageBox.Show(sb.ToString());
            this.btn07.Click += this.QuitarA;
        }

        private void QuitarA(object sender, EventArgs e)
        {
            this.btn08.Click += this.GuardarSQL;
        }

        private void GuardarSQL(object sender, EventArgs e)
        {
            string Query = "";

            foreach (Mascota item in this.mascotera.MisMascotas)
            {
                Query += string.Format("INSERT INTO Mascotas (Nombre, patas) VALUES ({0},{1})", "'"+Mascota.Nombre+"'", Mascota.Patas);
            }

            ConexionBD objetoBD = new ConexionBD();
            objetoBD.comando.CommandText = Query;
            objetoBD.conexion.Open();
            objetoBD.comando.ExecuteNonQuery();
            objetoBD.conexion.Close();


            this.btn09.Click += this.Mostrar;
        }

        private void btn12_Click(object sender, EventArgs e)
        {
            this.Close();
        }

    }

    [Serializable]
    public class Mascota
    {
        private static int _patas;
        private static string _nombre;

        static Mascota()
        {
            Mascota._patas = 8;
        }

        public Mascota(string nombre)
        {
            Mascota._nombre = nombre;
        }

        public static int Patas
        {
            get
            {
                return Mascota._patas;
            }
        }

        public static string Nombre
        {
            get
            {
                return Mascota._nombre;
            }
        }

        public string EmitirSonido()
        {
            throw new SinSonidoException("No emite sonido");

        }

      
    }

    [Serializable]
    public class Perro : Mascota, ISonido<string>
    {
        public new string EmitirSonido()
        {
            return "Ladrar";
        }

        public Perro(string nombre) : base(nombre)
        {

        }
    }

    public class SinSonidoException : Exception
    { 
        public SinSonidoException(string message) : base(message)
        {

        }
    }

    public class Mascotera<T> where T : Mascota //Una clase con esta firma se transforma en genérica, luego se le podrá pasar cualquier tipo;
    {
        //private int _capacidadMaxima;
        private List<T> _mascotas;

        public Mascotera()
        {
            this._mascotas = new List<T>();
            //this._capacidadMaxima = capacidad;
        }

        public List<T> MisMascotas
        {
            get
            {
                return this._mascotas;
            }
        }

        public static Mascotera<T> operator +(Mascotera<T> d, T a)
        {
            //bool aux = false;

            //if (d._mascotas.Count < d._capacidadMaxima)
            //{
            //    d._lista.Add(a);
            //    aux = true;
            //}
            d._mascotas.Add(a);

            return d;
        }

    }

    public interface ISonido<T>
    {
        string EmitirSonido();
    }

    public class ConexionBD
    {
        public SqlConnection conexion;
        public SqlCommand comando;
        private string datosConexion = "Data Source = (localdb)\\Pedrito; Initial Catalog = Final; Integrated Security=True";

        public ConexionBD()
        {
            this.conexion = new SqlConnection(datosConexion);
            this.comando = new SqlCommand();
            this.comando.CommandType = System.Data.CommandType.Text;
            this.comando.Connection = conexion;
        }
    }
}
