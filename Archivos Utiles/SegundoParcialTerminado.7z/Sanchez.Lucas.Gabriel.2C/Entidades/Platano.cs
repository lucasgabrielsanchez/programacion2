﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Platano : Fruta
    {
        public string paisOrigen;

        public override bool TieneCarozo
        {
            get { return false; }
        }

        public string Tipo { get { return "Plátano";} }

        /// <summary>
        /// Propiedad agregada a fin de mostrar los datos del objeto en el archivo serializado,
        /// llamando al método que muestra los datos del mismo para ahorrar código.
        /// </summary>
        public string PlatanoDatos
        {
            get { return this.FrutaToString(); }
            set { ;}
        }

        /// <summary>
        /// Agregado constructor por default para poder serializar/deserializar el objeto.
        /// </summary>
        public Platano()
        {
        }

        public Platano(float peso, ConsoleColor color, string pais) : base(peso, color)
        {
            this.paisOrigen = pais;
        }

        protected override string FrutaToString()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendFormat(base.FrutaToString());
            sb.AppendLine("Tipo: " + this.Tipo);
            sb.AppendLine("País de origen: " + this.paisOrigen);

            return sb.ToString();
        }

        public override string ToString()
        {
            return this.FrutaToString();
        }
    }
}
