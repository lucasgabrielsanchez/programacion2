﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Entidades
{
    [XmlInclude(typeof(Manzana))]//agregado para serializar la herencia.
    [XmlInclude(typeof(Platano))]
    public abstract class Fruta
    {
        private ConsoleColor _color;
        private float _peso;

        public abstract bool TieneCarozo { get; }

        public Fruta()//agregado para poder serializarse
        {
        }

        public Fruta(float peso, ConsoleColor color)
        {
            this._color = color;
            this._peso = peso;
        }

        protected virtual string FrutaToString()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendLine(this.GetType().Name);
            sb.AppendLine("----------------");
            sb.AppendLine("Color: "+this._color);
            sb.AppendLine("Peso: "+this._peso);
            sb.AppendLine("Tiene carozo: " + (this.TieneCarozo ? "Si" : "No"));

            return sb.ToString();

        }
    }
}
