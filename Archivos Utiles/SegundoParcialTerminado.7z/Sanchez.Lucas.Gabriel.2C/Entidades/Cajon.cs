﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Xml.Serialization;

namespace Entidades
{
    [XmlType("Cajón")]
    public class Cajon<T> : ISerializable
    {
        private int _capacidad;
        private List<T> _frutas;
        private float precioUnitario;

        /// <summary>
        /// Propiedad agregada a fin de mostrar los datos del objeto en el archivo serializado.
        /// </summary>
        public string CajonDatos
        {
            get
            {
                StringBuilder sb = new StringBuilder();

                sb.AppendLine("Cajón de " + typeof(T).Name + "s");
                sb.AppendLine("--------------------");
                sb.AppendLine("Capacidad: " + this._capacidad);
                sb.AppendLine("Cantidad total de frutas: " + this._frutas.Count());
                sb.AppendLine("Precio total: " + this.PrecioTotal);

                return sb.ToString();
            }
            set { ;}
        }

        public List<T> Frutas { get { return this._frutas; } }
        public float PrecioTotal { get { return (this.precioUnitario * this._frutas.Count); } }

        public Cajon()
        {
            this._frutas = new List<T>();
        }

        public Cajon(int capacidad, float precio) : this()
        {
            this._capacidad = capacidad;
            this.precioUnitario = precio;
        }

        public static Cajon<T> operator +(Cajon<T> c, T f)
        {
            if (c._frutas.Count < c._capacidad)
            {
                c._frutas.Add(f);
            }
            else
            {
                throw new CajonLlenoException("El cajón de "+typeof(T).Name+"s se llenó\n");
            }
            return c;
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendLine("Cajón de " + typeof(T).Name + "s");
            sb.AppendLine("--------------------");
            sb.AppendLine("Capacidad: " + this._capacidad);
            sb.AppendLine("Cantidad total de frutas: " + this._frutas.Count());
            sb.AppendLine("Precio total: " + this.PrecioTotal);
            sb.AppendLine("\nFrutas contenidas:\n");
            foreach (T item in this._frutas)
            {
                sb.AppendLine(item.ToString());
            }

            return sb.ToString();
        }

        /// <summary>
        /// Propiedad autodefinida utilizada "como" atributo.
        /// </summary>
        public string RutaArchivo { get; set; }

        public bool Deserializar()
        {
            try
            {
                XmlSerializer xs = new XmlSerializer(typeof(Cajon<T>));
                StreamReader sr = new StreamReader(this.RutaArchivo);
                xs.Deserialize(sr);
                sr.Close();
                return true;
            }
            catch
            {
                return false;
            }
        }

        public bool SerializarXML()
        {
            try
            {
                XmlSerializer xs = new XmlSerializer(typeof(Cajon<T>));
                StreamWriter sw = new StreamWriter(this.RutaArchivo);
                xs.Serialize(sw, this);
                sw.Close();
                return true;
            }
            catch
            {
                return false;
            }
        }
    }
}
