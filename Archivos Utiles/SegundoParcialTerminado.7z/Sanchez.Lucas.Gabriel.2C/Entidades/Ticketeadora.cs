﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Data;
using System.Data.SqlClient;

namespace Entidades
{
    public static class Ticketeadora
    {
        public static bool ImprimirTicket(this Cajon<Platano> c, string path)
        {
            try
            {
                StreamWriter sw = new StreamWriter(path);
                sw.WriteLine("Fecha y hora: " + DateTime.Now + " Precio total: " + c.PrecioTotal);
                sw.Close();
                return true;
            }
            catch
            {
                return false;
            }
        }

        public static string ObtenerPreciosBD(this ISerializable bd)
        {
            StringBuilder sb = new StringBuilder();

            SqlConnection conexion;
            conexion = new SqlConnection(Properties.Settings.Default.Setting);
            SqlCommand sc = new SqlCommand("SELECT * FROM PreciosFruta", conexion);
            conexion.Open();
            SqlDataReader dr = sc.ExecuteReader();
            while (dr.Read() != false)
            {
                sb.AppendFormat("ID : {0} - Descripción: {1} - Precio: {2}\n", dr[0], dr[1], dr[2]);
            }
            dr.Close();
            conexion.Close();

            return sb.ToString();
        }

    }
}
