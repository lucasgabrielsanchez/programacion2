﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entidades;

namespace ConsoleApplication1
{
    class Program
    {
        private static bool Deserializar(ISerializable obj)
        {
            return obj.Deserializar();
        }

        static void Main(string[] args)
        {

            Manzana m1 = new Manzana(4, ConsoleColor.Red, "Distribuidora1");
            Manzana m2 = new Manzana(5, ConsoleColor.Green, "Distribuidora2");
            Manzana m3 = new Manzana(6, ConsoleColor.Red, "Distribuidora3");

            Platano p1 = new Platano(1, ConsoleColor.Yellow, "Argentina");
            Platano p2 = new Platano(2, ConsoleColor.Green, "Paraguay");
            Platano p3 = new Platano(3, ConsoleColor.Yellow, "Brazil");

            //cajón de frutas
            Cajon<Fruta> cf = new Cajon<Fruta>(5, 20);

            try
            {
                cf += m1;
                cf += m2;
                cf += m3;
                cf += p1;
                cf += p2;
                cf += p3;
            }
            catch (CajonLlenoException c)
            {
                Console.WriteLine(c.Message);
            }

            Console.WriteLine(cf);

            Console.ReadLine();
            Console.Clear();

            //cajón de manzanas
            Cajon<Manzana> cm = new Cajon<Manzana>(2, 15);

            try
            {
                cm += m1;
                cm += m2;
                cm += m3;
            }
            catch (CajonLlenoException c)
            {
                Console.WriteLine(c.Message);
            }

            Console.WriteLine(cm);

            Console.ReadLine();
            Console.Clear();

            //cajón de plátanos
            Cajon<Platano> cp = new Cajon<Platano>(2, 10);

            try
            {
                cp += p1;
                cp += p2;
                cp += p3;
            }
            catch (CajonLlenoException c)
            {
                Console.WriteLine(c.Message);
            }

            Console.WriteLine(cp);

            Console.ReadLine();
            Console.Clear();

            m1.RutaArchivo = "Manzana.xml";//sólo le paso el nombre del archivo ya que por default la ruta es la del programa.
            Console.WriteLine("El objeto {1} {0} ser serializado" , (m1.SerializarXML() ? "Pudo" : "No pudo") , m1.GetType().Name);
            Console.WriteLine("El objeto {1} {0} ser deserializado", (m1.Deserializar() ? "Pudo" : "No pudo") , m1.GetType().Name);

            cf.RutaArchivo = "CajonFrutas.xml";//sólo le paso el nombre del archivo ya que por default la ruta es la del programa.
            Console.WriteLine("El objeto {1} {0} ser serializado" , (cf.SerializarXML() ? "Pudo" : "No pudo") , cf.GetType().Name);
            Console.WriteLine("El objeto {1} {0} ser deserializado", (cf.Deserializar() ? "Pudo" : "No pudo") , cf.GetType().Name);

            Console.ReadLine();
            Console.Clear();

            Console.WriteLine("El objeto {1} {0} ser etiquetado", (cp.ImprimirTicket("TicketCajonPlatano.txt") ? "Pudo" : "No pudo"), cf.GetType().Name);

            Console.ReadLine();
            Console.Clear();

            Console.WriteLine("Mostrando datos de la Base de Datos:\n"+m1.ObtenerPreciosBD());

            Console.ReadLine();
        }

        private static bool Serializar(ISerializable obj)
        {
            return obj.SerializarXML();
        }

        private static string ObtenerPreciosBD(ISerializable obj)
        {
            return obj.ObtenerPreciosBD();
        }
    }
}
